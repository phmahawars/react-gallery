<?php

namespace App\Http\Controllers;

use App\Models\Images;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Intervention\Image\Facades\Image;

// ini_set('memory_limit', '512M');
// ini_set('max_execution_time', '300');

class ImageController extends Controller
{
    public function get_single_image($id, $name, $width = null){
        $img = Images::where('id',$id)->where('name',$name)->first();
        $image = Image::make($img->image);
        if($width !== null){
            $image->resize($width, null, function ($constraint) {
                $constraint->aspectRatio();
            });
        }
        $resizedImageData = $image->encode($img->image_type);

        return response($resizedImageData)->header('Content-Type', 'image/'.$img->image_type);
    }
    // public function get_single_image($id, $name){
    //     $img = Images::where('id',$id)->where('name',$name)->first();
    //     return response($img->image)->header('Content-Type', 'image/png');
    // }
    public function images(Request $requsts){
        $data = DB::table('images')->select('id',"name",'user_id','image_type')->where('user_id',1)->orderBy('id', 'DESC')->get();
        return $data;
    }
    // public function add_images(Request $requsts){
        
    //     $image = new Images;
    //     $image->name = Str::random(40);
    //     $image->image = file_get_contents($requsts->file('image')->getRealPath());
    //     $image->user_id = 1;
    //     $image->image_type = $requsts->file('image')->getClientOriginalExtension();
    //     $image->save();
    //     return response()->json(['message'=>"Image upload successfully"],200);
    // }
    public function add_images(Request $requsts){
        $handle = fopen($requsts->file('image')->getRealPath(), "r");
        $fileData = '';
        while (($buffer = fgets($handle, 4096)) !== false) {
            $fileData .= $buffer;
        }
        $image = new Images;
        $image->name = Str::random(40);
        $image->image = $fileData;
        $image->user_id = 1;
        $image->image_type = $requsts->file('image')->getClientOriginalExtension();
        $image->save();
        fclose($handle);
        return response()->json(['message'=>"Image upload successfully"],200);
    }
}
