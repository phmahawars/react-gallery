<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Http\Response as IlluminateResponse;

class ImageAuth
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function handle(Request $request, Closure $next): Response
    {

        $response = $next($request);
        $fileExtention = ['png','jpg','jpeg','gif','webp'];
        $fileType = $request->file('image')->getClientOriginalExtension();
        if(in_array($fileType,$fileExtention)){
            return $response;
        }else{
            return response()->json(['message'=>'This image type not accepted','ext'=>$fileExtention],202);
        }
    }
}
