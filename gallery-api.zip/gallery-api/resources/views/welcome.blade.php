<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Upload using AJAX</title>
</head>
<body>

    <form id="uploadForm" enctype="multipart/form-data">
        <input type="file" name="image" id="file" required>
        <button type="submit">Upload File</button>
    </form>

    <div id="uploadStatus"></div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
          
            $('#uploadForm').on('submit', function(e) {
                e.preventDefault();

                // Create a FormData object to hold the file
                var formData = new FormData(this);

                $.ajax({
                    url: "http://127.0.0.1:8000/api/images",
                    type: "POST",
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        if (response.success) {
                            $('#uploadStatus').html('<p style="color: green;">' + response.success + '</p>');
                        } else {
                            $('#uploadStatus').html('<p style="color: red;">File upload failed!</p>');
                        }
                    },
                    error: function(response) {
                        $('#uploadStatus').html('<p style="color: red;">An error occurred.</p>');
                    }
                });
            });
        });
    </script>
</body>
</html>
